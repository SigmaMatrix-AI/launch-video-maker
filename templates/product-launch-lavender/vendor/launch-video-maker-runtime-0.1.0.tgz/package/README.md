# Launch Video Maker

An Agent skill for autonomously creating product promotional videos. First analyze the product's purpose, audience, selling points, and required features while capturing real pages and representative use cases. Then select an independent style and an adaptable reference template, plan the storyboard, implement a React film, handle sound, and conduct an independent review.

The runtime uses **React + TypeScript, unified frame control, Playwright, and FFmpeg**, without Remotion. Preview and export share scene source code, assets, and premixed audio; the Player is for viewing and inspection only.

## Status

The runnable development runtime provides project initialization, asset preparation, playback/pause/frame stepping/scrubbing, still capture, MP4 encoding, page capture, audio analysis, and review evidence bundles. Runtime technical validation, style validation, and commercial film acceptance are separate levels; passing tests does not mean a film meets commercial design standards.

The built-in [Google Vids reference template](templates/google-vids/template.md) provides a complete React recreation project; [Motion Design Promo](templates/motion-design-promo/template.md) provides a kinetic typography and showcase template preserving the existing 20-second rhythm. [TapVid Launch](templates/tapvid-launch/template.md) provides the revised 82-second capsule-to-composer promo with plane transitions and a frosted logo button. Discover production styles in `styles/`; `runtime/validation/` and the old `tests/fixtures/styles/` are for development validation only and are excluded from production template selection. User films belong in `films/`, which Git ignores.

## Installation and quick start

Supported target: macOS Apple Silicon, Node.js 24+, npm, FFmpeg, and ffprobe (with libx264/AAC). Other platforms have not been validated. FFmpeg is an external system tool; setup does not install system software automatically.

```bash
git clone https://github.com/SigmaMatrix-AI/launch-video-maker.git
cd launch-video-maker
npm ci
npm run build
node runtime/dist/cli.js doctor
npx playwright install chromium
node runtime/dist/cli.js init films/my-film
cd films/my-film
npm ci
npm run setup
npm run prepare
```

`init` generates project source, `brand-kit/`, production records, and a runtime package snapshot and dependency lockfile in `vendor/`. Moved projects can still be installed and run independently without the original skill directory; installing dependencies and Chromium requires network access. Place generated projects in `films/` by default, not in the production templates/styles directories.

A generated project's `prepare` is also an npm lifecycle script: ordinary `npm ci` / `npm install` automatically prepares media. To install dependencies only, use `npm ci --ignore-scripts`, then explicitly run `npm run prepare`; projects with media need FFmpeg available first.

Agents start with [SKILL.md](SKILL.md). The [runtime guide](references/runtime-usage.md) covers code interfaces and commands; the [production workflow](references/pipeline.md) describes each stage's deliverables.

## Commands and delivery behavior

Run the following commands through `npx lvm` inside a film project:

| Command | Purpose |
| --- | --- |
| `doctor` / `setup` | Check the environment / install project dependencies and a pinned Chromium version |
| `prepare` | Validate configuration, prepare media, and compile the shared 48 kHz stereo mix |
| `preview` | Start the preview in the background without opening a browser or displaying the address |
| `preview --open` | Open a browser when the user requests a preview |
| `still 42 /path/frame.png` | Capture the specified frame after assets are ready, without creating an MP4 |
| `render /path/film.mp4` | Explicitly export an H264/AAC MP4; refuse to overwrite existing files |
| `inspect /path/film.mp4` | Inspect actual encoding specifications and frame count |
| `capture URL /path/assets [selectors...]` | Capture 2× page and element screenshots, positions, and sources |
| `analyze-audio /path/music.wav` | Output waveform windows, peaks, energy, and transient candidates as JSON |
| `review-pack .lvm/review` | Create a unique evidence bundle: action/transition frames, mix, playback trace, context, and an unscored report |
| `review-check /absolute/bundle/review.json` | Verify version, file evidence, scope thresholds, and item-by-item retesting |
| `clean` | Remove known decode/Vite caches; retain review records and stop the preview first |

Deliver a reviewed project that can be previewed by default. Show the preview only when requested; run `render` after the user is satisfied and requests export. Technical tests may generate fixture MP4s, but this does not authorize automatic export of the user's film.

Reviews default to visual scope. Full CLI options and report instructions are in the [runtime guide](references/runtime-usage.md) and [independent reviewer guide](references/reviewer-prompt.md). A `review-check` exit code of 0 means only that the current scope passed; the full commercial conclusion for visual scope always remains incomplete. Tools do not automatically score or claim to have watched or listened.

## Design principles

- **Autonomous decisions.** Do not introduce stage approvals; ask only for necessary information that cannot reasonably be inferred.
- **Understand and capture the product first.** Establish purpose, audience, selling points, required features, and execution constraints in the first step while saving real screenshots, key states, and official use cases; after storyboarding, capture additional material only as needed.
- **Keep brand assets lightweight.** Collect only the logo and theme color by default. Treat the logo as an asset, use the theme color as a style accent, and preserve the appearance of real materials.
- **Product and brand evidence take priority.** User requirements and explicit brand standards come first. Reference films/templates supply action, shots, spatial staging, layout, and rhythm; styles supply color, typography, and compatible surface treatments.
- **Templates can be freely adapted.** React source can add or remove scenes, reorder the structure, or contribute only selected implementations.
- **Styles are document-centered.** A free-form `style.md` is usually enough; complex styles may include implementation references. A demo illustrates style application, is not a template, need not run independently, and does not require repairing its original project dependencies.
- **Keep assets in the film project.** Logos, fonts, page assets, BGM, and source records must not depend on external absolute paths on the author's machine.
- **Quality requires evidence.** A subagent uninvolved in production must actually watch the motion and listen. All seven dimensions must score ≥7.5/10, with no blockers or missing required evidence, to pass.

This does not provide a shot library, rigid templates, stage-by-stage co-creation, a visual editor, CapCut project export, publishing, or a cross-project brand platform.

## Development and validation

```bash
npm run build
npm test
LVM_LONG_TEST=1 npx tsx --test runtime/test/long-sync.test.ts
```

Tests run files serially by default to avoid contention between dependency installation and browser validation. Playback synchronization uses the audio device output clock and allows two frames of error within the preview scheduling window. Default tests cover real Chromium/FFmpeg, random and reverse frame access, missing assets, audio envelopes/clipping, variable-frame-rate media with nonzero PTS, actual MP4s, portable project installation, and review thresholds. The separately enabled 60-second test verifies known visual flash frames and audio impulses at the beginning, middle, and end.

When the two initial user-provided style packages are available locally, run `npx tsx runtime/validation/build-studies.ts /absolute/new/directory` to generate two new 12-second validation projects. This does not repair, run, or port the original demos, and does not output MP4s. See the [validation record](docs/validation.md) for detailed status.

## Directory structure

```text
SKILL.md                 Persistent Agent execution rules
references/              Production, brand, style, runtime, and review conventions
templates/               Runnable Google Vids, Motion Design Promo, and TapVid Launch reference templates
styles/                  Independent production style packages
films/                   User films and local experiments (Git-ignored)
runtime/src/             Packaged runtime core, media, audio, server, and CLI
runtime/web/             Lightweight Player
runtime/test/            Technical tests
runtime/validation/      Development validation film source, not reference templates
docs/plans/              Development plans
```

Git does not track empty directories; they may be absent after cloning. Agents should treat them as having no built-in references yet.

## Limitations and troubleshooting

- Source or asset changes invalidate the current preview/capture version. Stop the server and run `prepare` / `preview` again to avoid mixing old audio with new visuals.
- Video assets are predecoded to PNG; select the frame covering the target time using the original PTS. The entire imported clip is currently predecoded, so trim long footage first. See the runtime guide for cache limits and cleanup behavior.
- Audio speed changes use resampling and change pitch. Pitch-preserving speed changes, TTS, ASR, music generation, and source separation are not provided.
- `inspect` is a technical probe and does not replace watching the finished film, listening, or independent aesthetic evaluation. `review-check` validates the completeness of a human report and cannot establish that the reviewer actually watched or listened.
- Fix the original assets when fonts or images fail; do not hide errors with fixed waits or silent fallbacks. Use `doctor` to check tools; caches can be regenerated after `clean`.

## Contributing and licensing

Describe actual behavior changes, reproducible validation, and remaining limitations in submissions. Record sources and licenses for reference content and assets; do not commit generated caches or describe unverified aesthetic results as passed.

This repository has not yet specified a license and does not provide a `LICENSE` file. Third-party dependencies and referenced assets remain subject to their respective licenses; do not assume this project uses MIT or Apache licensing.
